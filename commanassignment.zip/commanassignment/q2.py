d={}
p=int(input("enter the number"))
for i in range(1,p+1):
	k=i
	v=i*i
	d.update({k:v})
print(d)

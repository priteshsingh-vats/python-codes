a=[5,7,9,3,2,1,4,2,6,3,0,9,8]
for i in a:
	if i<5:
		print(i)
list1=[i for i in a if i<5]
print(list1)
p=int(input("enter the number to be found"))
print(p in a)

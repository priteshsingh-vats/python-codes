p=int(input("enter the number whose input is to be found"))
result=1
for i in range(1,p+1):
	result=result*i
print(result,"is the factorial of",p)

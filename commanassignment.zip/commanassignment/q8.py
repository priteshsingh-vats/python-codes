p=4
for i in range(p):
	for j in range(i+1):
		print(i+1,end="")
		i=i+1
	print()
